﻿using Microsoft.EntityFrameworkCore;
using CustomerOrderingSystem.Models;

namespace CustomerOrderingSystem.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // DbSet for Customer model
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }

    }
}

