﻿using CustomerOrderingSystem.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CustomerOrderingSystem.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System;

namespace CustomerOrderingSystem.Controllers
{
    public class CustomerController : Controller
    {
        private readonly AppDbContext _context;

        // Constructor that injects the AppDbContext
        public CustomerController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Register
        [HttpGet]
        public IActionResult Register()
        {
            return View(new Customer());
        }

        // POST: Register
        [HttpPost]
        public async Task<IActionResult> Register(Customer customer)
        {
            if (ModelState.IsValid)
            {
                // Check if the email already exists
                var existingCustomer = await _context.Customers
                                                      .FirstOrDefaultAsync(c => c.Email == customer.Email);
                if (existingCustomer != null)
                {
                    // If the email exists, show an error
                    ModelState.AddModelError(string.Empty, "This email is already registered.");
                    return View(customer);
                }

                // Save the customer details to the database
                _context.Customers.Add(customer);
                await _context.SaveChangesAsync();

                // Redirect to the login page after successful registration
                return RedirectToAction("Login", "Customer");
            }

            // If model state is not valid, return the same view with errors
            return View(customer);
        }

        // GET: Login
        [HttpGet]
        public IActionResult Login()
        {
            return View(new Customer());
        }

        // POST: Login
        [HttpPost]
        public async Task<IActionResult> Login(string email, string password)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError(string.Empty, "Email and Password are required.");
                return View();
            }

            var existingCustomer = await _context.Customers
                                                  .FirstOrDefaultAsync(c => c.Email == email);

            if (existingCustomer != null && existingCustomer.Password == password)
            {
                // Store a session or authentication cookie here if needed
                HttpContext.Session.SetString("CustomerEmail", existingCustomer.Email);
                HttpContext.Session.SetInt32("CustomerID", existingCustomer.CustomerID);

                // Redirect to the Home page on successful login
                return RedirectToAction("Index", "Home");
            }

            // Show error if email or password is incorrect
            ModelState.AddModelError(string.Empty, "Invalid email or password.");

            return View();
        }

        // GET: Logout
        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Customer");
        }

        // GET: OrderHistory
        [HttpGet]
        public async Task<IActionResult> OrderHistory()
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var customer = await _context.Customers
                                         .Include(c => c.Orders) // Assuming a navigation property for Orders
                                         .FirstOrDefaultAsync(c => c.Email == email);

            if (customer == null || customer.Orders == null || !customer.Orders.Any())
            {
                ViewBag.Message = "No orders found.";
                return View();
            }

            return View(customer.Orders);
        }

        // GET: CreateOrder
        [HttpGet]
        public IActionResult CreateOrder()
        {
            return View(new Order());
        }

        // POST: CreateOrder
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateOrder(Order order, string actionType)
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var customer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == email);
            if (customer == null)
            {
                return RedirectToAction("Login", "Customer");
            }

            order.CustomerID = customer.CustomerID;
            order.OrderDate = DateTime.Now;

            if (actionType == "Save")
            {
                order.OrderStatus = "Saved";
            }
            else if (actionType == "Confirm")
            {
                order.OrderStatus = "Confirmed";
            }

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return RedirectToAction("OrderHistory");
        }

        // GET: EditOrder
        [HttpGet]
        public async Task<IActionResult> EditOrder(int id)
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var customer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == email);
            if (customer == null)
            {
                return RedirectToAction("Login", "Customer");
            }

            var order = await _context.Orders.FirstOrDefaultAsync(o => o.OrderID == id && o.CustomerID == customer.CustomerID);
            if (order == null)
            {
                return RedirectToAction("OrderHistory");
            }

            return View(order);
        }

        // POST: EditOrder
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditOrder(Order order)
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var customer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == email);
            if (customer == null)
            {
                return RedirectToAction("Login", "Customer");
            }

            // Set the CustomerID to ensure the order is associated with the correct customer
            order.CustomerID = customer.CustomerID;

            // Remove the Customer property from ModelState to prevent validation errors
            ModelState.Remove("Customer");

            if (!ModelState.IsValid)
            {
                return View(order);
            }

            var existingOrder = await _context.Orders.FirstOrDefaultAsync(o => o.OrderID == order.OrderID && o.CustomerID == customer.CustomerID);
            if (existingOrder == null)
            {
                return RedirectToAction("OrderHistory");
            }

            existingOrder.ItemName = order.ItemName;
            existingOrder.DeliveryAddress = order.DeliveryAddress;
            existingOrder.OrderStatus = order.OrderStatus;

            await _context.SaveChangesAsync();
            return RedirectToAction("OrderHistory");
        }

        // GET: DeleteOrder
        [HttpGet]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var order = await _context.Orders.FirstOrDefaultAsync(o => o.OrderID == id && o.OrderStatus == "Saved");
            if (order == null)
            {
                return RedirectToAction("OrderHistory");
            }

            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
            return RedirectToAction("OrderHistory");
        }

        // GET: OrderDetails
        [HttpGet]
        public async Task<IActionResult> OrderDetails(int id)
        {
            var email = HttpContext.Session.GetString("CustomerEmail");
            if (string.IsNullOrEmpty(email))
            {
                return RedirectToAction("Login", "Customer");
            }

            var order = await _context.Orders.FirstOrDefaultAsync(o => o.OrderID == id);
            if (order == null)
            {
                return RedirectToAction("OrderHistory");
            }

            return View(order);
        }
    }
}
